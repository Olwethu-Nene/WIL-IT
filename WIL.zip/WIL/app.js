// User profile data
const userProfile = {
    fullName: 'John Doe',
    email: 'john@example.com',
    phone: '+27 123 456 789',
    address: '123 Main St, Johannesburg',
    skills: 'Communication, Problem-solving',
    bio: 'Experienced professional looking to connect with quality service providers.'
};

// Provider data
const providerData = {
    'grass-cutters': [
        {
            name: 'Thabo Mkhize',
            rating: 4.8,
            reviewCount: 45,
            review: 'Excellent grass cutting service! Very professional.',
            location: 'Sandton',
            experience: '5 years',
            specialties: 'Residential lawns, Garden maintenance',
            hourlyRate: 'R150/hour',
            image: 'images/Grass Cutter1.png',
            bio: 'Professional grass cutting specialist with extensive experience in residential and commercial properties.'
        },
        {
            name: 'Joshua Jackson',
            rating: 4.9,
            reviewCount: 62,
            review: 'Best in the business! Highly recommended.',
            location: 'Rosebank',
            experience: '7 years',
            specialties: 'Commercial properties, Estate management',
            hourlyRate: 'R180/hour',
            image: 'images/Grass Cutter2.png',
            bio: 'Specialized in large-scale grass cutting and estate maintenance with a focus on quality and reliability.'
        }
        ,
        {
            name: 'Judina Cooper',
            rating: 4.7,
            reviewCount: 34,
            review: 'Very reliable and neat work.',
            location: 'Boksburg',
            experience: '4 years',
            specialties: 'Small yards, Hedge trimming',
            hourlyRate: 'R140/hour',
            image: 'images/Grass Cutter3.png',
            bio: 'Friendly and efficient gardener focusing on tidy lawns and hedges.'
        },
        {
            name: 'Simphiwe Dlamini',
            rating: 4.6,
            reviewCount: 27,
            review: 'Punctual and does a thorough job!',
            location: 'Roodepoort',
            experience: '3 years',
            specialties: 'Lawn care, Weed control',
            hourlyRate: 'R130/hour',
            image: 'images/Grass Cutter4.png',
            bio: 'Local lawn care specialist with great attention to detail.'
        },
        {
            name: 'Kabelo Molefe',
            rating: 4.9,
            reviewCount: 48,
            review: 'Fantastic results and very thorough.',
            location: 'Midrand',
            experience: '6 years',
            specialties: 'Residential lawns, Garden cleanups',
            hourlyRate: 'R160/hour',
            image: 'images/Grass Cutter5.png',
            bio: 'Experienced in residential lawn care and seasonal garden maintenance.'
        }
    ],
    'plumbers': [
        {
            name: 'David van der Merwe',
            rating: 4.7,
            reviewCount: 38,
            review: 'Fixed our leak quickly and efficiently!',
            location: 'Parktown',
            experience: '10 years',
            specialties: 'Emergency repairs, Installations',
            hourlyRate: 'R250/hour',
            image: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d',
            bio: 'Licensed plumber with a decade of experience in residential and commercial plumbing.'
        },
        {
            name: 'John Botha',
            rating: 4.6,
            reviewCount: 29,
            review: 'Professional service, fair pricing.',
            location: 'Centurion',
            experience: '8 years',
            specialties: 'Bathroom renovations, Pipe installations',
            hourlyRate: 'R230/hour',
            image: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7',
            bio: 'Expert in bathroom renovations and modern plumbing solutions.'
        }
    ],
    'gardeners': [
        {
            name: 'Maria Santos',
            rating: 5.0,
            reviewCount: 71,
            review: 'Transformed our garden beautifully!',
            location: 'Hyde Park',
            experience: '12 years',
            specialties: 'Landscape design, Plant care',
            hourlyRate: 'R200/hour',
            image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330',
            bio: 'Award-winning landscape designer with a passion for creating beautiful outdoor spaces.'
        },
        {
            name: 'Peter Nkosi',
            rating: 4.8,
            reviewCount: 54,
            review: 'Great attention to detail!',
            location: 'Randburg',
            experience: '6 years',
            specialties: 'Organic gardening, Vegetable gardens',
            hourlyRate: 'R170/hour',
            image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e',
            bio: 'Specialist in organic and sustainable gardening practices.'
        }
    ],
    'drivers': [
        {
            name: 'Ahmed Hassan',
            rating: 4.9,
            reviewCount: 89,
            review: 'Safe and reliable driver!',
            location: 'Midrand',
            experience: '15 years',
            specialties: 'Long-distance, Corporate transport',
            hourlyRate: 'R120/hour',
            image: 'https://images.unsplash.com/photo-1568602471122-7832951cc4c5',
            bio: 'Professional driver with an excellent safety record and extensive route knowledge.'
        },
        {
            name: 'Joseph Moyo',
            rating: 4.7,
            reviewCount: 43,
            review: 'Always on time and courteous.',
            location: 'Fourways',
            experience: '9 years',
            specialties: 'Airport transfers, Event transport',
            hourlyRate: 'R130/hour',
            image: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce',
            bio: 'Reliable and professional transport service for all occasions.'
        }
    ],
    'electricians': [
        {
            name: 'Michael Brown',
            rating: 4.8,
            reviewCount: 56,
            review: 'Expert electrical work!',
            location: 'Roodepoort',
            experience: '11 years',
            specialties: 'Home automation, Solar installations',
            hourlyRate: 'R280/hour',
            image: 'https://images.unsplash.com/photo-1557862921-37829c790f19',
            bio: 'Certified electrician specializing in modern home automation and renewable energy.'
        },
        {
            name: 'Steven Jacobs',
            rating: 4.9,
            reviewCount: 67,
            review: 'Solved our complex wiring issues!',
            location: 'Kempton Park',
            experience: '14 years',
            specialties: 'Industrial electrical, Fault finding',
            hourlyRate: 'R300/hour',
            image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a',
            bio: 'Industrial and commercial electrical expert with advanced problem-solving skills.'
        }
    ]
    ,
    'domestic-workers': [
        {
            name: 'Thandiwe Nkosi',
            rating: 4.9,
            reviewCount: 58,
            review: 'Very thorough and trustworthy. My house was spotless!',
            location: 'Soweto',
            experience: '8 years',
            specialties: 'House cleaning, Laundry, Childcare support',
            hourlyRate: 'R120/hour',
            image: 'images/Domestic Worker1.png',
            bio: 'Experienced domestic worker offering reliable household cleaning and childcare assistance.'
        },
        {
            name: 'Sibusiso Khumalo',
            rating: 4.7,
            reviewCount: 34,
            review: 'Punctual and great attention to detail.',
            location: 'Johannesburg',
            experience: '5 years',
            specialties: 'Deep cleaning, Ironing, Grocery runs',
            hourlyRate: 'R110/hour',
            image: 'images/Domestic Worker2.png',
            bio: 'Reliable domestic helper skilled in deep cleaning and household errands.'
        },
        {
            name: 'Ayesha Patel',
            rating: 4.8,
            reviewCount: 41,
            review: 'Friendly and efficient — highly recommended.',
            location: 'Durban',
            experience: '6 years',
            specialties: 'General housekeeping, Cooking, Pet care',
            hourlyRate: 'R130/hour',
            image: 'images/Domestic Worker3.png',
            bio: 'Offers comprehensive housekeeping services including light cooking and pet care.'
        },
        {
            name: 'Naledi Maseko',
            rating: 4.6,
            reviewCount: 29,
            review: 'Hardworking and trustworthy with gentle manner.',
            location: 'Centurion',
            experience: '4 years',
            specialties: 'Elder care assistance, Laundry, Home organization',
            hourlyRate: 'R115/hour',
            image: 'images/Domestic Worker4.png',
            bio: 'Compassionate domestic worker experienced in elder care and home organization.'
        }
    ]
};

// Messages data
const messagesList = [
    { id: 1, title: 'Thabo Mkhize', preview: 'Thanks for choosing my services! When would you like me to start?' },
    { id: 2, title: 'Maria Santos', preview: 'I have some great ideas for your garden. Let\'s discuss!' },
    { id: 3, title: 'Ahmed Hassan', preview: 'Confirmed for pickup at 8 AM tomorrow.' }
];

// Services data
const allServices = [
    { name: 'Grass Cutters', description: 'Professional lawn care and maintenance', path: 'grass-cutters' },
    { name: 'Plumbers', description: 'Expert plumbing services and repairs', path: 'plumbers' },
    { name: 'Gardeners', description: 'Beautiful garden design and maintenance', path: 'gardeners' },
    { name: 'Drivers', description: 'Reliable transportation services', path: 'drivers' },
    { name: 'Electricians', description: 'Licensed electrical work and installations', path: 'electricians' },
    { name: 'Domestic Workers', description: 'Coming soon...', path: null }
];

// Toast notification
function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    if (type === 'error') {
        toast.classList.add('error');
    }
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.remove();
    }, 3000);
}

// Modal functions
function showModal(content) {
    const modal = document.createElement('div');
    modal.className = 'modal active';
    modal.innerHTML = `
        <div class="modal-content">
            <span class="close-modal" onclick="closeModal()">&times;</span>
            ${content}
        </div>
    `;
    document.body.appendChild(modal);
    // prevent background from scrolling while modal is open
    try { document.body.style.overflow = 'hidden'; } catch (e) {}
    modal.onclick = (e) => {
        if (e.target === modal) closeModal();
    };
}

function closeModal() {
    const modal = document.querySelector('.modal');
    if (modal) modal.remove();
    try { document.body.style.overflow = ''; } catch (e) {}
}

// Accounts modal: list users, create, switch, delete
function openAccountsModal() {
    const users = getUsers();
    const rows = users.map(u => `
        <div style="display:flex;align-items:center;gap:12px;padding:8px;border-bottom:1px solid #f0f0f0;">
            <div style="flex:1;">
                <div style="font-weight:800">${escapeHtml(u.fullName || '(no name)')}</div>
                <div style="font-size:12px;color:#666">${escapeHtml(u.email || '')} • ${escapeHtml(u.role || 'customer')}</div>
            </div>
            <div style="display:flex;gap:8px;">
                <button class="btn btn-secondary" onclick="switchUser('${(u.email||'').replace(/'/g,"\\'")}')">Switch</button>
                <button class="btn btn-secondary" onclick="removeUserConfirm('${(u.email||'').replace(/'/g,"\\'")}')">Delete</button>
            </div>
        </div>
    `).join('');

    const content = `
        <h3>Accounts</h3>
        <div style="max-height:240px;overflow:auto;margin-bottom:12px;border:1px solid rgba(0,0,0,0.04);border-radius:8px;">${rows || '<div style="padding:12px;color:#666">No local accounts yet.</div>'}</div>
        <h4>Create New Local Account</h4>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px;">
            <input id="acctName" placeholder="Full name">
            <input id="acctEmail" placeholder="Email">
            <input id="acctPhone" placeholder="Phone">
            <input id="acctAddress" placeholder="Address">
        </div>
        <div style="margin-bottom:8px;">
            <select id="acctRole"><option value="customer">Customer</option><option value="provider">Provider</option></select>
        </div>
        <div style="display:flex;gap:8px;justify-content:flex-end;">
            <button class="btn btn-secondary" onclick="closeModal()">Close</button>
            <button class="btn btn-primary" onclick="createLocalUserFromModal()">Create</button>
        </div>
    `;
    showModal(content);
    // after modal is added to DOM, focus the amount input so user doesn't have to scroll
    setTimeout(() => {
        const amt = document.getElementById('paymentAmount');
        if (amt) {
            amt.focus();
            if (typeof amt.select === 'function') amt.select();
            // ensure modal is visible and scrolled to the top
            const modal = document.querySelector('.modal');
            if (modal) modal.scrollTop = 0;
            // also ensure the modal content is centered in viewport
            const mc = document.querySelector('.modal .modal-content');
            if (mc && typeof mc.scrollIntoView === 'function') mc.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }, 60);
}

function switchUser(email) {
    setCurrentUser(email);
    showToast('Switched user to ' + email);
    closeModal();
    // refresh UI where relevant
    if (document.getElementById('profileName')) populateProfileFields();
    if (document.getElementById('contactsList')) renderContacts();
}

function removeUserConfirm(email) {
    if (!confirm('Remove local account ' + email + '?')) return;
    removeUserByEmail(email);
    showToast('Account removed');
    closeModal();
    openAccountsModal();
}

function createLocalUserFromModal() {
    const name = (document.getElementById('acctName') || {}).value || 'Local User';
    const email = (document.getElementById('acctEmail') || {}).value || ('user_' + Date.now() + '@local');
    const phone = (document.getElementById('acctPhone') || {}).value || '';
    const address = (document.getElementById('acctAddress') || {}).value || '';
    const role = (document.getElementById('acctRole') || {}).value || 'customer';
    const user = { fullName: name, email, phone, address, skills: '', bio: '', role };
    addOrUpdateUser(user);
    setCurrentUser(email);
    showToast('Created & switched to ' + email);
    closeModal();
}

// Helper functions
function togglePassword(inputId) {
    const input = document.getElementById(inputId);
    input.type = input.type === 'password' ? 'text' : 'password';
}

// Sidebar toggle for small screens
function toggleSidebar() {
    const isOpen = document.body.classList.toggle('sidebar-open');
    // update aria-expanded on any hamburger buttons
    document.querySelectorAll('.hamburger').forEach(btn => btn.setAttribute('aria-expanded', isOpen));
}

// Close sidebar when clicking overlay (if present)
document.addEventListener('click', (e) => {
    if (!document.body.classList.contains('sidebar-open')) return;
    const overlay = document.querySelector('.sidebar-overlay');
    if (overlay && (e.target === overlay)) {
        toggleSidebar();
    }
});

// --- Local multi-user helpers (simulated accounts stored in localStorage) ---
function getUsers() {
    try { return JSON.parse(localStorage.getItem('users') || '[]'); } catch (e) { return []; }
}

function saveUsers(users) {
    localStorage.setItem('users', JSON.stringify(users || []));
}

function findUserByEmail(email) {
    if (!email) return null;
    return getUsers().find(u => (u.email || '').toLowerCase() === (email || '').toLowerCase()) || null;
}

function addOrUpdateUser(user) {
    if (!user || !user.email) return;
    const users = getUsers();
    const idx = users.findIndex(u => (u.email || '').toLowerCase() === (user.email || '').toLowerCase());
    if (idx !== -1) users[idx] = Object.assign({}, users[idx], user);
    else users.push(user);
    saveUsers(users);
}

function setCurrentUser(email) {
    if (!email) return;
    localStorage.setItem('current_user_email', email);
    const u = findUserByEmail(email);
    if (u) localStorage.setItem('user_profile', JSON.stringify(u));
}

function getActiveProfile() {
    const cur = localStorage.getItem('current_user_email');
    if (cur) {
        const u = findUserByEmail(cur);
        if (u) return u;
    }
    // if no explicit current user, but we have users in localStorage, pick the first one
    const users = getUsers();
    if (users && users.length) {
        // prefer a user whose email matches stored `user_profile` if present
        try {
            const stored = JSON.parse(localStorage.getItem('user_profile') || 'null');
            if (stored && stored.email) {
                const matched = users.find(uu => (uu.email || '').toLowerCase() === (stored.email || '').toLowerCase());
                if (matched) {
                    // set as current for consistency
                    setCurrentUser(matched.email);
                    return matched;
                }
            }
        } catch (e) {}
        // otherwise pick the first user and set as current
        setCurrentUser(users[0].email);
        return users[0];
    }
    const stored = JSON.parse(localStorage.getItem('user_profile') || 'null');
    return stored || userProfile;
}

function removeUserByEmail(email) {
    const users = getUsers().filter(u => (u.email || '').toLowerCase() !== (email || '').toLowerCase());
    saveUsers(users);
}

function handleLogin(event) {
    event.preventDefault();
    showToast('Login successful!');
    // remember the logged-in email so profile can reflect it
    const email = (document.getElementById('loginEmail') || {}).value || '';
    const selectedRole = (document.getElementById('loginRole') || {}).value || '';
    // If an account exists, switch to it; otherwise create a minimal profile and switch
    let existing = findUserByEmail(email);
    if (existing) {
        setCurrentUser(existing.email);
        try { localStorage.setItem('user_profile', JSON.stringify(existing)); } catch (e) {}
    } else {
        const profile = Object.assign({}, userProfile, { email: email || userProfile.email });
        if (selectedRole) profile.role = selectedRole;
        addOrUpdateUser(profile);
        setCurrentUser(profile.email);
        try { localStorage.setItem('user_profile', JSON.stringify(profile)); } catch (e) {}
    }
    // persist role the user chose on login (if provided) so UI can adapt
    if (selectedRole) localStorage.setItem('current_user_role', selectedRole);

    setTimeout(() => {
        window.location.href = 'home.html';
    }, 1000);
}

function handleSignup(event) {
    event.preventDefault();
    const password = document.getElementById('signupPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    
    if (password !== confirmPassword) {
        showToast('Passwords do not match!', 'error');
        return;
    }
    // create and persist a basic profile from the signup form
    const name = (document.getElementById('signupName') || {}).value || '';
    const email = (document.getElementById('signupEmail') || {}).value || '';
    const phone = (document.getElementById('signupPhone') || {}).value || '';
    const address = (document.getElementById('signupAddress') || {}).value || '';
    const skills = (document.getElementById('signupSkills') || {}).value || '';
    const roleEl = document.querySelector('input[name="signupRole"]:checked');
    const role = (roleEl && roleEl.value) ? roleEl.value : 'customer';

    const newProfile = Object.assign({}, userProfile, {
        fullName: name || userProfile.fullName,
        email: email || userProfile.email,
        phone: phone || userProfile.phone,
        address: address || userProfile.address,
        skills: skills || userProfile.skills,
        role: role || 'customer'
    });
    // persist into users[] and set current user
    addOrUpdateUser(newProfile);
    if (email) {
        setCurrentUser(email);
        try { localStorage.setItem('user_profile', JSON.stringify(newProfile)); } catch (e) {}
    }
    if (role) localStorage.setItem('current_user_role', role);

    showToast('Account created successfully!');
    setTimeout(() => {
        window.location.href = 'login.html';
    }, 1500);
}

function handleSignOut() {
    showToast('Signed out successfully');
    // clear current user marker
    localStorage.removeItem('current_user_email');
    setTimeout(() => {
        window.location.href = 'index.html';
    }, 1000);
}

function editProfile() {
    const inputs = document.querySelectorAll('.profile-form input, .profile-form textarea');
    inputs.forEach(input => input.disabled = false);
    
    const btnGroup = document.querySelector('.btn-group');
    btnGroup.innerHTML = `
        <button class="btn btn-secondary" onclick="cancelEdit()">Cancel</button>
        <button class="btn btn-primary" onclick="saveProfile()">Save Changes</button>
    `;
}

function saveProfile() {
    // update the active user's profile and persist into users[]
    const active = getActiveProfile() || Object.assign({}, userProfile);
    active.fullName = document.getElementById('profileName').value;
    active.email = document.getElementById('profileEmail').value;
    active.phone = document.getElementById('profilePhone').value;
    active.address = document.getElementById('profileAddress').value;
    active.skills = document.getElementById('profileSkills').value;
    // role may be present on profile page (if editable)
    const roleEl = document.getElementById('profileRole');
    if (roleEl) active.role = roleEl.value;
    active.bio = document.getElementById('profileBio').value;

    showToast('Profile updated successfully!');
    // persist the updated profile into users[] and as user_profile
    addOrUpdateUser(active);
    localStorage.setItem('user_profile', JSON.stringify(active));
    if (active.email) setCurrentUser(active.email);
    // reload to re-lock inputs and refresh display
    window.location.reload();
}

function cancelEdit() {
    window.location.reload();
}

function filterServices() {
    const search = document.getElementById('serviceSearch').value.toLowerCase();
    const services = allServices.filter(s => 
        s.name.toLowerCase().includes(search) || 
        s.description.toLowerCase().includes(search)
    );
    
    document.getElementById('servicesList').innerHTML = services.map(service => `
        <div class="service-card" style="text-align: left;" onclick="${service.path ? `window.location.href='providers.html?service=${service.path}'` : ''}">
            <h3 style="color: #3498db;">${service.name}</h3>
            <p style="color: #7f8c8d; margin-top: 8px;">${service.description}</p>
        </div>
    `).join('');
}

function filterMessages() {
    const q = (document.getElementById('messageSearch') || {}).value || '';
    const search = q.toLowerCase();
    const contactsListEl = document.getElementById('contactsList');
    if (contactsListEl) {
        // filter contact items
        const items = contactsListEl.querySelectorAll('.contact-item');
        items.forEach(item => {
            const text = item.textContent.toLowerCase();
            item.style.display = text.includes(search) ? 'flex' : 'none';
        });
        return;
    }

    // fallback behaviour (legacy)
    const messages = messagesList.filter(m => 
        m.title.toLowerCase().includes(search) || 
        m.preview.toLowerCase().includes(search)
    );
    
    const messagesListEl = document.getElementById('messagesList');
    if (messagesListEl) {
        messagesListEl.innerHTML = messages.map(msg => `
            <div class="message-card">
                <h3>${msg.title}</h3>
                <p>${msg.preview}</p>
            </div>
        `).join('');
    }
}

// --- Page chat & contacts (messages page) ---
function getChatKeys() {
    const keys = [];
    for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k && k.startsWith('chat_')) keys.push(k);
    }
    // sort by last message time (desc)
    keys.sort((a,b) => {
        const aArr = JSON.parse(localStorage.getItem(a) || '[]');
        const bArr = JSON.parse(localStorage.getItem(b) || '[]');
        const aTime = aArr.length ? aArr[aArr.length-1].time : 0;
        const bTime = bArr.length ? bArr[bArr.length-1].time : 0;
        return bTime - aTime;
    });
    return keys;
}

function providerNameFromKey(key) {
    return key.replace(/^chat_/, '').replace(/_/g, ' ');
}

function findProviderImageByName(name) {
    const keyed = name.toLowerCase();
    for (const svc in providerData) {
        const arr = providerData[svc];
        for (const p of arr) {
            if (p.name.toLowerCase() === keyed) return p.image;
        }
    }
    return 'images/Logo4.png';
}

// Load persisted provider listings (if any) and merge into in-memory providerData
function loadPersistedProviderData() {
    try {
        const persisted = JSON.parse(localStorage.getItem('provider_data') || 'null');
        if (persisted && typeof persisted === 'object') {
            for (const k in persisted) {
                providerData[k] = persisted[k];
            }
        }
    } catch (err) {
        console.warn('Failed to load persisted provider data', err);
    }
}

// Save providerData to localStorage
function persistProviderData() {
    try {
        localStorage.setItem('provider_data', JSON.stringify(providerData));
    } catch (err) {
        console.warn('Failed to persist provider data', err);
    }
}

// Populate profile form fields from persisted profile (if present)
function populateProfileFields() {
    let profile = getActiveProfile();
    // If profile appears to be the demo default, try to fallback to first user in users[]
    if (profile && profile.fullName === userProfile.fullName && profile.email === userProfile.email) {
        const users = getUsers();
        if (users && users.length) {
            profile = users[0];
            if (profile.email) setCurrentUser(profile.email);
        }
    }
    const nameEl = document.getElementById('profileName');
    if (!nameEl) return; // not on profile page
    document.getElementById('profileName').value = profile.fullName || '';
    document.getElementById('profileEmail').value = profile.email || '';
    document.getElementById('profilePhone').value = profile.phone || '';
    document.getElementById('profileAddress').value = profile.address || '';
    document.getElementById('profileSkills').value = profile.skills || '';
    document.getElementById('profileBio').value = profile.bio || '';
    // role (customer / provider)
    const roleEl = document.getElementById('profileRole');
    if (roleEl) roleEl.value = profile.role || 'customer';
    // ensure inputs are disabled by default
    // avatar
    const avatar = document.getElementById('profileAvatar');
    if (avatar) avatar.src = profile.image || 'images/Logo4.png';
    // show profile banner with current email and switch control
    const banner = document.getElementById('profileBanner');
    const bannerEmail = document.getElementById('bannerEmail');
    if (banner && bannerEmail) {
        bannerEmail.textContent = profile.email || '(no email)';
        banner.style.display = 'flex';
    }
    // provider-specific UI
    const dashboard = document.getElementById('providerDashboard');
    if (dashboard) {
        if (profile.role === 'provider') {
            dashboard.style.display = 'block';
            // populate service type select
            const sel = document.getElementById('providerServiceType');
            if (sel) {
                sel.innerHTML = allServices.filter(s => s.path).map(s => `<option value="${s.path}">${s.name}</option>`).join('');
            }
            // render existing ads/messages for this provider
            renderProviderAds();
            renderProviderMessages();
                renderProviderPayments();
            // wire reply button
            const replyBtn = document.getElementById('providerReplyBtn');
            if (replyBtn) replyBtn.onclick = providerReplySend;
        } else {
            dashboard.style.display = 'none';
        }
    }
    document.querySelectorAll('.profile-form input, .profile-form textarea').forEach(i => i.disabled = true);
    // customer-side transaction list
    renderCustomerPayments();
}

// Handle profile image upload: save to user_profile and update UI
function handleProfileImageUpload(e) {
    const file = (e.target && e.target.files && e.target.files[0]) || null;
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function(evt) {
        const dataUrl = evt.target.result;
        const stored = getActiveProfile() || Object.assign({}, userProfile);
        stored.image = dataUrl;
        // persist onto users list and active profile
        addOrUpdateUser(stored);
        setCurrentUser(stored.email || stored.fullName);
        const avatar = document.getElementById('profileAvatar');
        if (avatar) avatar.src = dataUrl;
        showToast('Profile image uploaded');
        // if provider has existing provider entries, update their image too
        if (stored.role === 'provider' && stored.fullName) {
            for (const svc in providerData) {
                providerData[svc].forEach(p => {
                    if (p.name === stored.fullName) p.image = dataUrl;
                });
            }
            persistProviderData();
        }
    };
    reader.readAsDataURL(file);
}

// Advertise a service as the logged-in provider
function advertiseService(evt) {
    if (evt && evt.preventDefault) evt.preventDefault();
    const stored = getActiveProfile() || Object.assign({}, userProfile);
    if (!stored || stored.role !== 'provider') {
        showToast('You must be signed up as a provider to advertise services', 'error');
        return;
    }
    const servicePath = (document.getElementById('providerServiceType') || {}).value;
    const hourlyRate = (document.getElementById('providerHourlyRate') || {}).value || '';
    const specialties = (document.getElementById('providerSpecialties') || {}).value || '';
    const bio = (document.getElementById('providerBio') || {}).value || '';
    const fileInput = document.getElementById('providerImageInput');

    function addProvider(imageDataUrl) {
        const providerObj = {
            id: (window.editingAd && window.editingAd.id) ? window.editingAd.id : Date.now(),
            name: stored.fullName || 'Unnamed Provider',
            rating: 0,
            reviewCount: 0,
            review: '',
            location: stored.address || '',
            experience: '',
            specialties: specialties,
            hourlyRate: hourlyRate,
            image: imageDataUrl || stored.image || 'images/Logo4.png',
            bio: bio || stored.bio || ''
        };
        if (!servicePath) {
            showToast('Please choose a service category', 'error');
            return;
        }
        providerData[servicePath] = providerData[servicePath] || [];
        // support edit flow: if editingAd is set, replace existing entry
        if (window.editingAd && window.editingAd.service === servicePath) {
            const idx = providerData[servicePath].findIndex(p => p.id === window.editingAd.id);
            if (idx !== -1) {
                providerData[servicePath][idx] = Object.assign({}, providerData[servicePath][idx], providerObj);
                window.editingAd = null;
            } else {
                providerData[servicePath].push(providerObj);
            }
        } else {
            providerData[servicePath].push(providerObj);
        }
        persistProviderData();
        showToast('Service advertised successfully');
        renderProviderAds();
        // reset editing state and submit button text
        const submitBtn = document.querySelector('#providerForm button[type="submit"]');
        if (submitBtn) submitBtn.textContent = 'Advertise Service';
        window.editingAd = null;
    }

    if (fileInput && fileInput.files && fileInput.files[0]) {
        const f = fileInput.files[0];
        const reader = new FileReader();
        reader.onload = function(ev) {
            addProvider(ev.target.result);
        };
        reader.readAsDataURL(f);
    } else {
        addProvider();
    }
}

// Edit an existing provider ad: populate the advertise form and set editingAd
function editProviderAd(servicePath, id) {
    const arr = providerData[servicePath] || [];
    const ad = arr.find(p => p.id === Number(id));
    if (!ad) return;
    document.getElementById('providerServiceType').value = servicePath;
    document.getElementById('providerHourlyRate').value = ad.hourlyRate || '';
    document.getElementById('providerSpecialties').value = ad.specialties || '';
    document.getElementById('providerBio').value = ad.bio || '';
    // show image input (leave as-is); set editing state
    window.editingAd = { service: servicePath, id: Number(id) };
    // update submit button text
    const submitBtn = document.querySelector('#providerForm button[type="submit"]');
    if (submitBtn) submitBtn.textContent = 'Save Changes';
    showToast('Loaded advertisement for editing');
}

// Delete a provider advertisement
function deleteProviderAd(servicePath, id) {
    if (!confirm('Delete this advertisement? This cannot be undone.')) return;
    providerData[servicePath] = (providerData[servicePath] || []).filter(p => p.id !== Number(id));
    persistProviderData();
    renderProviderAds();
    showToast('Advertisement removed');
}

// Render advertisements created by the current provider
function renderProviderAds() {
    const list = document.getElementById('providerAdsList');
    if (!list) return;
    const stored = getActiveProfile() || userProfile;
    const name = stored.fullName;
    const ads = [];
    for (const svc in providerData) {
        providerData[svc].forEach(p => { if (p.name === name) ads.push(Object.assign({ service: svc }, p)); });
    }
    if (!ads.length) {
        list.innerHTML = '<div class="muted">You have not advertised any services yet.</div>';
        return;
    }
    list.innerHTML = ads.map(a => `
        <div class="provider-ad-card" data-id="${a.id}">
            <img src="${a.image}" class="provider-ad-image"> 
            <div class="provider-ad-body">
                <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;">
                    <div>
                        <strong>${a.name}</strong>
                        <div style="font-size:13px;color:#666;">${a.specialties} • ${a.hourlyRate}</div>
                    </div>
                    <div class="provider-ad-actions">
                        <button class="btn btn-secondary" onclick="editProviderAd('${a.service}','${a.id}')">Edit</button>
                        <button class="btn btn-secondary" onclick="deleteProviderAd('${a.service}','${a.id}')">Delete</button>
                    </div>
                </div>
                <div style="margin-top:8px;color:#333;">${escapeHtml(a.bio || '')}</div>
            </div>
        </div>
    `).join('');
}

// Render messages for the provider (simple list) and show reply box
function renderProviderMessages() {
    const list = document.getElementById('providerMessagesList');
    if (!list) return;
    const stored = getActiveProfile() || userProfile;
    const name = stored.fullName;
    const key = `chat_${(name || '').replace(/\s+/g,'_')}`;
    const arr = JSON.parse(localStorage.getItem(key) || '[]');
    if (!arr.length) {
        list.innerHTML = '<div class="muted">No messages yet.</div>';
        return;
    }
    list.innerHTML = arr.map(m => `
        <div class="chat-row" style="padding:8px;border-bottom:1px solid #eee;">
            <div style="font-size:12px;color:#999">${new Date(m.time).toLocaleString()}</div>
            <div style="margin-top:4px;">${m.sender === 'user' ? '<strong>Customer:</strong>' : '<strong>You:</strong>'} ${escapeHtml(m.text)}</div>
        </div>
    `).join('');
}

// Send a reply as provider from the profile dashboard
function providerReplySend() {
    const input = document.getElementById('providerReplyInput');
    if (!input) return;
    const text = input.value.trim();
    if (!text) return;
    const stored = getActiveProfile() || userProfile;
    const name = stored.fullName;
    const key = `chat_${(name || '').replace(/\s+/g,'_')}`;
    addChatMessage(key, { sender: 'provider', text, time: Date.now() });
    input.value = '';
    renderProviderMessages();
}

// --- Payments (simulated, client-side) ---
function getPayments() {
    try { return JSON.parse(localStorage.getItem('payments') || '[]'); } catch (e) { return []; }
}

function savePayment(payment) {
    const arr = getPayments();
    arr.push(payment);
    localStorage.setItem('payments', JSON.stringify(arr));
}

function formatCurrency(amount) {
    const n = Number(amount) || 0;
    try {
        return new Intl.NumberFormat('en-ZA', { style: 'currency', currency: 'ZAR' }).format(n);
    } catch (e) {
        return 'R' + n.toFixed(2);
    }
}

function openPaymentModal(providerName, suggestedAmount) {
    const profile = getActiveProfile();
    const suggested = suggestedAmount || (suggestedAmount === 0 ? '0' : '');
    const content = `
        <h3>Pay ${escapeHtml(providerName)}</h3>
        <div class="payment-form">
            <div class="form-group">
                <label>Amount</label>
                <input id="paymentAmount" type="number" step="0.01" value="${suggested}" placeholder="Amount (e.g. 150.00)">
                <div class="small">Payments are simulated locally for demo purposes only.</div>
            </div>
            <div class="form-group">
                <label>Cardholder Name</label>
                <input id="paymentCardName" type="text" value="${escapeHtml((profile && profile.fullName) || '')}">
            </div>
            <div class="form-row">
                <div class="form-group" style="flex:2;">
                    <label>Card Number</label>
                    <input id="paymentCardNumber" type="text" placeholder="4242 4242 4242 4242">
                </div>
                <div style="flex:1; display:flex; flex-direction:column; gap:8px;">
                    <div class="form-group"><label>Expiry</label><input id="paymentExpiry" type="text" placeholder="MM/YY"></div>
                    <div class="form-group"><label>CVV</label><input id="paymentCvv" type="text" placeholder="123"></div>
                </div>
            </div>
            <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:8px;">
                <button class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                <button class="btn btn-primary" onclick="processPaymentFromModal('${(providerName||'').replace(/'/g,"\\'")}')">Pay Now</button>
            </div>
        </div>
    `;
    showModal(content);
}

function processPaymentFromModal(providerName) {
    const amountEl = document.getElementById('paymentAmount');
    if (!amountEl) return;
    const amount = parseFloat(amountEl.value);
    if (!amount || isNaN(amount) || amount <= 0) { showToast('Please enter a valid amount', 'error'); return; }
    const cardName = (document.getElementById('paymentCardName') || {}).value || '';
    const cardNumber = (document.getElementById('paymentCardNumber') || {}).value || '';
    // basic masking/validation skipped — this is a demo
    showToast('Processing payment...');
    // simulate processing delay
    setTimeout(() => {
        const payer = getActiveProfile() || { fullName: cardName || 'Local Customer', email: 'local@user' };
        const payment = {
            id: Date.now(),
            providerName: providerName,
            payerName: payer.fullName || '',
            payerEmail: payer.email || '',
            amount: Number(amount),
            time: Date.now(),
            status: 'completed'
        };
        savePayment(payment);
        // send a receipt message from Ubunye Community Services to the customer
        sendReceiptMessage(payment);
        closeModal();
        showToast('Payment successful');
        // refresh any open payment lists
        renderProviderPayments();
        renderCustomerPayments();
    }, 1100);
}

// Create a system message containing the receipt reference and attach to a Ubunye chat
function sendReceiptMessage(payment) {
    if (!payment || !payment.id) return;
    const key = 'chat_Ubunye_Community_Services';
    const arr = JSON.parse(localStorage.getItem(key) || '[]');
    const text = `Payment receipt available: ${formatCurrency(payment.amount)} to ${payment.providerName}. Receipt ID: ${payment.id}`;
    arr.push({ id: Date.now()+1, sender: 'ubunye', text: text, time: Date.now(), receiptId: payment.id });
    localStorage.setItem(key, JSON.stringify(arr));
    renderContacts();
}

function generateReceiptHtml(payment) {
    if (!payment) return '<p>Receipt not found</p>';
    const html = `
    <!doctype html>
    <html>
    <head>
      <meta charset="utf-8">
      <title>Receipt ${payment.id}</title>
      <style>body{font-family:Arial,Helvetica,sans-serif;padding:24px;color:#222} h1{color:#16a34a} .meta{margin-top:8px;color:#555} .line{margin:12px 0;padding:12px;background:#f8fafc;border-radius:8px;border:1px solid #eef2f7}</style>
    </head>
    <body>
      <h1>Ubunye Community Services</h1>
      <div class="meta">Receipt ID: ${payment.id}</div>
      <div class="meta">Date: ${new Date(payment.time).toLocaleString()}</div>
      <div class="line"><strong>Paid To:</strong> ${escapeHtml(payment.providerName || '')}</div>
      <div class="line"><strong>Payer:</strong> ${escapeHtml(payment.payerName || payment.payerEmail || '')}</div>
      <div class="line"><strong>Amount:</strong> ${formatCurrency(payment.amount)}</div>
      <div style="margin-top:18px;color:#666;font-size:13px;">This is an automatically generated receipt for your records. Ubunye Community Services does not process payments, this demo saves a local record only.</div>
    </body>
    </html>
    `;
    return html;
}

// Ensure jsPDF is loaded (from CDN) before generating PDF receipts
function ensureJsPdfLoaded() {
    return new Promise((resolve, reject) => {
        if (window.jspdf && window.jspdf.jsPDF) return resolve(window.jspdf);
        const existing = document.querySelector('script[data-name="jspdf"]');
        if (existing) {
            existing.addEventListener('load', () => resolve(window.jspdf));
            existing.addEventListener('error', () => reject(new Error('Failed to load jsPDF')));
            return;
        }
        const script = document.createElement('script');
        script.src = 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js';
        script.setAttribute('data-name', 'jspdf');
        script.onload = () => resolve(window.jspdf);
        script.onerror = () => reject(new Error('Failed to load jsPDF'));
        document.head.appendChild(script);
    });
}

async function downloadReceipt(paymentId) {
    const payments = getPayments();
    const p = payments.find(x => Number(x.id) === Number(paymentId));
    if (!p) { showToast('Receipt not found', 'error'); return; }
    // try to generate PDF via jsPDF; fallback to HTML download
    try {
        await ensureJsPdfLoaded();
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        doc.setFontSize(16);
        doc.text('Ubunye Community Services', 14, 20);
        doc.setFontSize(11);
        doc.text(`Receipt ID: ${p.id}`, 14, 34);
        doc.text(`Date: ${new Date(p.time).toLocaleString()}`, 14, 42);
        doc.text(`Paid To: ${p.providerName}`, 14, 56);
        doc.text(`Payer: ${p.payerName || p.payerEmail}`, 14, 64);
        doc.text(`Amount: ${formatCurrency(p.amount)}`, 14, 72);
        doc.text('This is an automatically generated receipt for your records.', 14, 94);
        doc.save(`receipt_${p.id}.pdf`);
    } catch (err) {
        // fallback to HTML file download
        const html = generateReceiptHtml(p);
        const blob = new Blob([html], { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `receipt_${p.id}.html`;
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(url);
    }
}

// Helper: read file as data URL (returns Promise)
function readFileAsDataURL(file) {
    return new Promise((resolve, reject) => {
        if (!file) return resolve(null);
        const reader = new FileReader();
        reader.onload = (e) => resolve(e.target.result);
        reader.onerror = (e) => reject(e);
        reader.readAsDataURL(file);
    });
}

function renderAttachmentHTML(attachment) {
    if (!attachment) return '';
    const name = escapeHtml(attachment.name || 'file');
    const url = attachment.dataUrl;
    if (!url) return '';
    if ((attachment.type || '').startsWith('image/')) {
        return `<div class="attachment"><img src="${url}" alt="${name}"><a href="${url}" download="${name}">Download ${name}</a></div>`;
    }
    return `<div class="attachment"><a href="${url}" download="${name}">Download ${name}</a></div>`;
}

function renderProviderPayments() {
    const profile = getActiveProfile();
    const container = document.getElementById('providerPaymentsList');
    if (!container || !profile) return;
    const name = profile.fullName;
    const payments = getPayments().filter(p => p.providerName === name).sort((a,b) => b.time - a.time);
    if (!payments.length) { container.innerHTML = '<div class="muted">No payments received yet.</div>'; return; }
    container.innerHTML = payments.map(p => `
        <div class="payment-row">
            <div class="left">${escapeHtml(p.payerName || p.payerEmail)} — ${formatCurrency(p.amount)}</div>
            <div class="right">${new Date(p.time).toLocaleString()} <button class="btn btn-pay" onclick="downloadReceipt('${p.id}')" style="margin-left:8px;">Download</button></div>
        </div>
    `).join('');
}

function renderCustomerPayments() {
    const profile = getActiveProfile();
    const container = document.getElementById('customerPaymentsList');
    if (!container || !profile) return;
    const email = profile.email;
    const payments = getPayments().filter(p => p.payerEmail === email).sort((a,b) => b.time - a.time);
    if (!payments.length) { container.innerHTML = '<div class="muted">No transactions yet.</div>'; return; }
    container.innerHTML = payments.map(p => `
        <div class="payment-row">
            <div class="left">To ${escapeHtml(p.providerName)} — ${formatCurrency(p.amount)}</div>
            <div class="right">${new Date(p.time).toLocaleString()} <button class="btn btn-pay" onclick="downloadReceipt('${p.id}')" style="margin-left:8px;">Download</button></div>
        </div>
    `).join('');
}


function renderContacts() {
    const container = document.getElementById('contactsList');
    if (!container) return;
    // Start with chats that have messages (most-recent first), then append the hardcoded default order
    const hardcodedNames = [
        'Thabo Mkhize',
        'Maria Santos',
        'Ahmed Hassan',
        'Judina Cooper',
        'Simphiwe Dlamini',
        'Kabelo Molefe'
    ];

    const recentKeys = getChatKeys(); // sorted by last message time desc
    const recentNames = recentKeys.map(k => providerNameFromKey(k));
    const recentSet = new Set(recentNames);
    // Merge: recent first, then any remaining hardcoded names in original order
    const orderedNames = [...recentNames, ...hardcodedNames.filter(n => !recentSet.has(n))];

        // filter out any chats the user deleted
        const deleted = JSON.parse(localStorage.getItem('deleted_chats') || '[]');
        const deletedSet = new Set(deleted);

        container.innerHTML = orderedNames
            .filter(name => !deletedSet.has(`chat_${name.replace(/\s+/g, '_')}`))
            .map(name => {
        const key = `chat_${name.replace(/\s+/g, '_')}`;
        const msgs = JSON.parse(localStorage.getItem(key) || '[]');
            const lastMsg = msgs.length ? msgs[msgs.length-1] : null;
            const last = lastMsg ? lastMsg.text : (messagesList.find(m => m.title === name) || {}).preview || '';
            const lastTime = lastMsg ? lastMsg.time : 0;
        const img = findProviderImageByName(name);
            const snippet = escapeHtml(last).slice(0,70);
            return `
                    <div class="contact-item" data-key="${key}" onclick="openConversation('${name.replace(/'/g, "\\'")}')">
                        <img src="${img}" class="avatar" alt="${name}">
                        <div class="meta">
                            <div style="display:flex;gap:8px;align-items:center;">
                                <div class="name">${name}</div>
                                <div class="contact-time">${lastTime ? formatTime(lastTime) : ''}</div>
                            </div>
                            <div class="snippet">${snippet}</div>
                        </div>
                    </div>
            `;
    }).join('');

    // attach right-click handlers for delete on contacts
    container.querySelectorAll('.contact-item').forEach(ci => {
        ci.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            const key = ci.getAttribute('data-key');
            if (!key) return;
            if (confirm('Delete this conversation? This action cannot be undone.')) {
                deleteChat(key);
            }
        });
    });
}

// human-readable relative time (short)
function formatTime(ts) {
    if (!ts) return '';
    const dt = new Date(ts);
    // format as HH:MM using locale-aware two-digit hour/minute
    return dt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

// Helpers for deleted chats
function getDeletedChats() {
    return JSON.parse(localStorage.getItem('deleted_chats') || '[]');
}

function addDeletedChat(key) {
    const arr = getDeletedChats();
    if (!arr.includes(key)) {
        arr.push(key);
        localStorage.setItem('deleted_chats', JSON.stringify(arr));
    }
}

let currentConversationKey = null;

function openConversation(providerName) {
    const key = `chat_${providerName.replace(/\s+/g, '_')}`;
    currentConversationKey = key;
    const header = document.getElementById('conversationHeader');
    if (header) header.textContent = providerName;
    renderChatMessagesFor(key, 'pageChatMessages');
    // wire send button
    const sendBtn = document.getElementById('pageChatSendBtn');
    const input = document.getElementById('pageChatInput');
    const fileInput = document.getElementById('pageChatFile');
    if (sendBtn && input) {
        sendBtn.onclick = () => {
            (async () => {
                const text = (input && input.value) ? input.value.trim() : '';
                const file = (fileInput && fileInput.files && fileInput.files[0]) ? fileInput.files[0] : null;
                let attachment = null;
                if (file) {
                    try { const dataUrl = await readFileAsDataURL(file); attachment = { name: file.name, type: file.type, dataUrl }; } catch (e) { console.warn('Failed to read file', e); }
                }
                if (!text && !attachment) return;
                pageAddChatMessage(key, { sender: 'user', text, time: Date.now(), attachment });
                if (input) input.value = '';
                if (fileInput) fileInput.value = '';
            })();
        };
    }
}

function renderChatMessagesFor(key, containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;
    const arr = JSON.parse(localStorage.getItem(key) || '[]');
    container.innerHTML = arr.map(m => {
        const cls = m.sender === 'user' ? 'user' : (m.sender === 'ubunye' ? 'provider' : 'provider');
        const receiptBtn = m.receiptId ? `<div style="margin-top:8px;"><button class=\"btn btn-pay\" onclick=\"downloadReceipt('${m.receiptId}')\">Download Receipt</button></div>` : '';
        return `
        <div class="chat-bubble ${cls}" data-id="${m.id}">
            <div class="bubble-text">${escapeHtml(m.text)}</div>
            ${receiptBtn}
            ${renderAttachmentHTML(m.attachment)}
            <div class="bubble-time">${formatTime(m.time)}</div>
        </div>
    `; }).join('');
    container.scrollTop = container.scrollHeight;
    // refresh contacts list to reorder
    renderContacts();

    // attach right-click on message bubbles for delete
    container.querySelectorAll('.chat-bubble').forEach(b => {
        b.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            const id = Number(b.getAttribute('data-id'));
            if (!id) return;
            if (confirm('Delete this message?')) deleteMessage(key, id);
        });
    });
}

function pageAddChatMessage(key, message) {
    // ensure message has id and time
    message.id = message.id || Date.now();
    message.time = message.time || Date.now();
    const arr = JSON.parse(localStorage.getItem(key) || '[]');
    arr.push(message);
    localStorage.setItem(key, JSON.stringify(arr));
    renderChatMessagesFor(key, 'pageChatMessages');
    // auto-reply demo
    if (message.sender === 'user') {
        setTimeout(() => {
            const arr2 = JSON.parse(localStorage.getItem(key) || '[]');
            arr2.push({ id: Date.now() + 1, sender: 'provider', text: 'Thanks, I received your message. I will respond shortly.', time: Date.now() });
            localStorage.setItem(key, JSON.stringify(arr2));
            renderChatMessagesFor(key, 'pageChatMessages');
        }, 900);
    }
}

// initialize messages page contacts on load
document.addEventListener('DOMContentLoaded', () => {
    // load any persisted provider listings first
    loadPersistedProviderData();
    // insert a floating Accounts button so demos can switch users
    if (!document.getElementById('accountsBtn')) {
        const btn = document.createElement('button');
        btn.id = 'accountsBtn';
        btn.className = 'accounts-btn';
        btn.title = 'Accounts & Switch User';
        btn.innerText = 'Accounts';
        btn.onclick = openAccountsModal;
        document.body.appendChild(btn);
    }
    // render contacts list if messages page is active
    if (document.getElementById('contactsList')) {
        renderContacts();
        const first = getChatKeys()[0];
        if (first) {
            const name = providerNameFromKey(first);
            openConversation(name);
        }
    }
    // populate profile page fields if present
    if (document.getElementById('profileName')) {
        populateProfileFields();
        // wire image upload input
        const imgIn = document.getElementById('profileImageInput');
        if (imgIn) imgIn.addEventListener('change', handleProfileImageUpload);
        // provider image input will be read by advertiseService when submitting
    }
});

function filterProviders() {
    const search = document.getElementById('providerSearch').value.toLowerCase();
    const providersList = document.getElementById('providersList');
    const cards = providersList.querySelectorAll('.provider-card');
    
    cards.forEach(card => {
        const text = card.textContent.toLowerCase();
        card.style.display = text.includes(search) ? 'block' : 'none';
    });
}

/* Chat modal for contacting a provider (local-only, persisted in localStorage) */
function openChat(providerName) {
    const key = `chat_${providerName.replace(/\s+/g, '_')}`;
    const messages = JSON.parse(localStorage.getItem(key) || '[]');

    // create modal
    const modal = document.createElement('div');
    modal.className = 'modal active chat-modal';
    modal.innerHTML = `
        <div class="modal-content chat-window">
            <div class="chat-header">
                <strong>Chat with ${providerName}</strong>
                <button class="close-chat" onclick="closeChat()">&times;</button>
            </div>
            <div class="chat-messages" id="chatMessages"></div>
            <div class="chat-input-row">
                <input id="chatInput" placeholder="Type a message..." />
                <input id="chatFile" type="file" style="margin-left:8px;" />
                <button id="chatSendBtn" class="btn btn-primary">Send</button>
            </div>
        </div>
    `;
    document.body.appendChild(modal);

    renderChatMessages(key);

    // send handler
    document.getElementById('chatSendBtn').onclick = () => {
        (async () => {
            const input = document.getElementById('chatInput');
            const fileIn = document.getElementById('chatFile');
            const text = (input && input.value) ? input.value.trim() : '';
            const file = (fileIn && fileIn.files && fileIn.files[0]) ? fileIn.files[0] : null;
            let attachment = null;
            if (file) {
                try { const dataUrl = await readFileAsDataURL(file); attachment = { name: file.name, type: file.type, dataUrl }; } catch (e) { console.warn('Failed to read file', e); }
            }
            if (!text && !attachment) return;
            addChatMessage(key, { sender: 'user', text, time: Date.now(), attachment });
            if (input) input.value = '';
            if (fileIn) fileIn.value = '';
        })();
    };

    // close on overlay click
    modal.onclick = (e) => { if (e.target === modal) closeChat(); };
}

function closeChat() {
    const modal = document.querySelector('.chat-modal');
    if (modal) modal.remove();
}

function addChatMessage(key, message) {
    message.id = message.id || Date.now();
    message.time = message.time || Date.now();
    const arr = JSON.parse(localStorage.getItem(key) || '[]');
    arr.push(message);
    localStorage.setItem(key, JSON.stringify(arr));
    renderChatMessages(key);
    renderContacts();

    // simple automated provider reply for demo
    if (message.sender === 'user') {
        setTimeout(() => {
            const arr2 = JSON.parse(localStorage.getItem(key) || '[]');
            arr2.push({ id: Date.now() + 1, sender: 'provider', text: 'Thanks, I received your message. I will respond shortly.', time: Date.now() });
            localStorage.setItem(key, JSON.stringify(arr2));
            renderChatMessages(key);
            renderContacts();
        }, 800);
    }
}

function renderChatMessages(key) {
    const container = document.getElementById('chatMessages');
    if (!container) return;
    const arr = JSON.parse(localStorage.getItem(key) || '[]');
    container.innerHTML = arr.map(m => {
        const cls = m.sender === 'user' ? 'user' : (m.sender === 'ubunye' ? 'provider' : 'provider');
        const receiptBtn = m.receiptId ? `<div style="margin-top:8px;"><button class=\"btn btn-pay\" onclick=\"downloadReceipt('${m.receiptId}')\">Download Receipt</button></div>` : '';
        return `
        <div class="chat-bubble ${cls}" data-id="${m.id}">
            <div class="bubble-text">${escapeHtml(m.text)}</div>
            ${receiptBtn}
            ${renderAttachmentHTML(m.attachment)}
            <div class="bubble-time">${formatTime(m.time)}</div>
        </div>
    `; }).join('');
    container.scrollTop = container.scrollHeight;

    // attach right-click on message bubbles for delete (modal)
    container.querySelectorAll('.chat-bubble').forEach(b => {
        b.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            const id = Number(b.getAttribute('data-id'));
            if (!id) return;
            if (confirm('Delete this message?')) deleteMessage(key, id);
        });
    });
}

// Delete a single message from a chat
function deleteMessage(key, messageId, e) {
    if (e) e.stopPropagation();
    const arr = JSON.parse(localStorage.getItem(key) || '[]');
    const filtered = arr.filter(m => m.id !== messageId);
    localStorage.setItem(key, JSON.stringify(filtered));
    // re-render current chat(s)
    if (document.getElementById('chatMessages')) renderChatMessages(key);
    if (document.getElementById('pageChatMessages')) renderChatMessagesFor(key, 'pageChatMessages');
    renderContacts();
}

// Delete an entire chat (conversation)
function deleteChat(key, e) {
    if (e) e.stopPropagation();
    if (!confirm('Delete this conversation? This action cannot be undone.')) return;
    localStorage.removeItem(key);
    // record deleted chat so it doesn't reappear in the hardcoded list
    addDeletedChat(key);
    // if deleted chat is open, clear conversation pane
    if (currentConversationKey === key) {
        currentConversationKey = null;
        const header = document.getElementById('conversationHeader'); if (header) header.textContent = '';
        const container = document.getElementById('pageChatMessages'); if (container) container.innerHTML = '';
    }
    renderContacts();
}

function escapeHtml(unsafe) {
    return String(unsafe)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
}
