# Ubunye Community Services (Static Site)

This is a simple HTML/CSS/JS site. The main HTML file is `UbunyeCommunityServices` and it links to:

- `styles.css` — all styling
- `app.js` — all client-side logic

## Quick start

You can open the site directly in a browser, or serve it with a tiny local web server.

### Option 1 — Open directly (recommended: rename first)

Because the main file currently has no `.html` extension, rename it to make browsers recognize it as HTML:

```powershell
# In PowerShell
cd "c:\Users\olwet\OneDrive\Desktop\WIL"
Rename-Item UbunyeCommunityServices index.html
# Then double-click index.html in Explorer, or:
ii .\index.html
```

If you prefer to keep the name:

```powershell
# Most browsers still open it, but some may not detect content-type correctly
cd "c:\Users\olwet\OneDrive\Desktop\WIL"
ii .\UbunyeCommunityServices
```

### Option 2 — Run a local static server

This is a nice dev setup and avoids any file:// quirks.

Python (if installed):

```powershell
cd "c:\Users\olwet\OneDrive\Desktop\WIL"
python -m http.server 8080
# Open http://localhost:8080/index.html
```

Node.js (if installed):

```powershell
cd "c:\Users\olwet\OneDrive\Desktop\WIL"
npx http-server -p 8080
# Open http://localhost:8080/index.html
```

> If you didn't rename the file, open `http://localhost:8080/UbunyeCommunityServices`. Some servers may show it as plain text without the .html extension; renaming is recommended.

## Project structure

```
WIL/
├─ UbunyeCommunityServices    # main HTML file (consider renaming to index.html)
├─ styles.css                 # extracted styles
└─ app.js                     # extracted scripts
```

## Notes

- The app uses hash-based navigation, so it works fine without a server.
- All images are remote, no backend required.
- If you plan to deploy, just upload these three files to any static host (GitHub Pages, Netlify, etc.).
